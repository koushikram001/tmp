## installation

Install the dependencies
```shell
npm install
```
Start the server
```shell
npm run dev
```
